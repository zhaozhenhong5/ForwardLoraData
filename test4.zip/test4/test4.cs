using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using System.Net.Http;
using Microsoft.Azure.EventHubs;
using System.Text;
using System.Net.Http.Headers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace test4
{
    public static class test4
    {
        [FunctionName("test4")]
    //    public static async Task RunAsync([EventHubTrigger("%HubName%", Connection = 
    //   "RouterConnection", ConsumerGroup = "%ConsumerGroupForwardLoraData%")]EventData 
    //    eventData, ILogger log, ExecutionContext context)
       public static async Task RunAsync([EventHubTrigger("todaairhub", Connection = 
      "Endpoint=sb://iothub-ns-todaairhub-.net/;SharedAccessKeyName=iothubowner;SharedAccessKey=alZIUc2jONc5i+Q=;EntityPath=todaairhub", ConsumerGroup = "loradata")]EventData 
       eventData, ILogger log, ExecutionContext context)
       {
            //var configuration = BuildConfiguration(context);
            var bodyBytes = eventData.Body.Array;
            var deviceId = GetDeviceId(eventData);
            var payload = GetPayload(bodyBytes);
            //var requestUri = configuration[ConfigurationKeys.WebApiUrl];
            var requestUri = "http://192.168.0.111:9999"; // or the URL you want to send data to
            var httpClient = CreateHttpClient();

            var measurement = new LoraMeasurement
            {
                DeviceId = deviceId,
                Json = payload,
            };
            var message = await httpClient.PostAsJsonAsync(requestUri, measurement);

             log.LogInformation(message.IsSuccessStatusCode
                ? $"ForwardLoraData: request sent successfully"
                : $"ForwardLoraData: request not sent successfully - {message.ReasonPhrase}");
        }

        public class LoraMeasurement
        {
            public string DeviceId { get; set; }
            public string GatewayId { get; set; }
            public string Json { get; set; }
        }
        private static HttpClient CreateHttpClient()
        {
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return httpClient;
        }

        private static string GetPayload(byte[] body)
        {
            var json = Encoding.UTF8.GetString(body);
            return json;
        }

        private static string GetDeviceId(EventData message)
        {
            return message.SystemProperties["todaair55"].ToString();
        }     

        // priate static IConfigurationRoot BuildConfiguration(ExecutionContext context)
        // {
        //     return new ConfigurationBuilder()
        //         .SetBasePath(context.FunctionAppDirectory)
        //         .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
        //         .AddEnvironmentVariables()
        //         .Build();
        // }
    }
}
